#!/usr/bin/env python3
"""Gửi kết quả dựng video về webhook Make (bỏ qua nếu chưa cài MAKE_WEBHOOK_URL)."""
import base64
import json
import os
from pathlib import Path

import requests

url = os.environ.get("MAKE_WEBHOOK_URL", "").strip()
if not url:
    print("[callback] Chưa có secret MAKE_WEBHOOK_URL -> bỏ qua")
    raise SystemExit(0)

payload = {}
try:
    payload = json.loads(base64.b64decode(os.environ.get("PAYLOAD", "")).decode("utf-8"))
except Exception:
    pass

meta = {}
mp = Path("out/meta.json")
if mp.exists():
    meta = json.loads(mp.read_text(encoding="utf-8"))

video_url = os.environ.get("VIDEO_URL", "")
ok = os.environ.get("JOB_STATUS") == "success" and bool(video_url)

data = {
    "status": "success" if ok else "error",
    "row": payload.get("row"),
    "title": payload.get("title", ""),
    "body": payload.get("body", ""),
    "hashtags": payload.get("hashtags", ""),
    "p1": payload.get("p1", ""),
    "video_url": video_url if ok else "",
    "duration": meta.get("duration"),
    "run_url": os.environ.get("RUN_URL", ""),
}
r = requests.post(url, json=data, timeout=30)
print("[callback]", r.status_code, data["status"], data["row"])
