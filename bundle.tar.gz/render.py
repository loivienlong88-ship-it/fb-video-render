#!/usr/bin/env python3
"""
Dựng video dọc 1080x1920 từ kịch bản JSON (miễn phí, không watermark).

Đầu vào (JSON, truyền qua biến môi trường PAYLOAD dạng base64 hoặc file):
{
  "row": 16,
  "title": "...", "body": "...", "hashtags": "...",
  "scenes": [ {"text": "câu đọc 1", "image": "https://..."}, ... ]
}

Các bước:
  1. Giọng đọc: edge-tts (vi-VN-HoaiMyNeural) + mốc thời gian từng chữ.
     Dự phòng: gTTS (không có mốc chữ -> chia đều thời gian).
  2. Ảnh: tải về, cắt vừa khung dọc; ảnh lỗi thì dùng ảnh cảnh trước / nền màu.
  3. FFmpeg: hiệu ứng zoom/pan từng cảnh, ghép cảnh, đốt phụ đề ASS
     (4 chữ/dòng, chữ đang đọc màu vàng, nền hộp đen), ghép tiếng.
Đầu ra: out/video.mp4 + out/meta.json
"""
import asyncio
import base64
import json
import os
import subprocess
import sys
from pathlib import Path

import requests
from PIL import Image, ImageDraw

W, H, FPS = 1080, 1920, 30
VOICE = os.environ.get("VOICE", "vi-VN-HoaiMyNeural")
RATE = os.environ.get("VOICE_RATE", "+8%")
WORDS_PER_LINE = 4
SCENE_PAD = 0.35          # giây nghỉ cuối mỗi cảnh
BRAND = os.environ.get("BRAND", "Shop Long Nhi")
FONT_NAME = os.environ.get("FONT_NAME", "Be Vietnam Pro")
FONT_DIR = os.environ.get("FONT_DIR", "fonts")
FAKE_TTS = os.environ.get("FAKE_TTS") == "1"   # chỉ dùng khi test không có mạng

OUT = Path("out")
WORK = Path("work")


def log(*a):
    print("[render]", *a, flush=True)


def run(cmd):
    log(" ".join(str(c) for c in cmd[:6]), "...")
    subprocess.run(cmd, check=True)


def probe_duration(path):
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=nw=1:nk=1", str(path)],
        capture_output=True, text=True, check=True)
    return float(r.stdout.strip())


# ---------------------------------------------------------------- 1. TTS
async def tts_edge(text, mp3):
    import edge_tts
    try:
        com = edge_tts.Communicate(text, VOICE, rate=RATE, boundary="WordBoundary")
    except TypeError:  # edge-tts bản cũ không có tham số boundary
        com = edge_tts.Communicate(text, VOICE, rate=RATE)
    words = []
    with open(mp3, "wb") as f:
        async for ch in com.stream():
            if ch["type"] == "audio":
                f.write(ch["data"])
            elif ch["type"] == "WordBoundary":
                s = ch["offset"] / 1e7
                words.append([s, s + ch["duration"] / 1e7, ch["text"]])
    if not words:
        raise RuntimeError("edge-tts không trả mốc chữ")
    return words


def tts_gtts(text, mp3):
    from gtts import gTTS
    gTTS(text, lang="vi").save(str(mp3))
    return None


def tts_fake(text, mp3):
    dur = max(2.0, len(text.split()) * 0.32)
    run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i",
         f"sine=frequency=220:duration={dur}", "-q:a", "4", str(mp3)])
    return None


def even_words(text, dur):
    toks = text.split()
    step = dur / max(1, len(toks))
    return [[i * step, (i + 1) * step, t] for i, t in enumerate(toks)]


def make_voice(text, mp3):
    words = None
    if FAKE_TTS:
        tts_fake(text, mp3)
    else:
        for attempt in range(3):
            try:
                words = asyncio.run(tts_edge(text, mp3))
                break
            except Exception as e:  # noqa
                log(f"edge-tts lỗi lần {attempt + 1}: {e}")
        else:
            log("chuyển sang gTTS")
            tts_gtts(text, mp3)
    dur = probe_duration(mp3)
    if not words:
        words = even_words(text, dur)
    return words, dur


# ---------------------------------------------------------------- 2. ẢNH
def fallback_image(path, idx):
    colors = [(33, 87, 50), (120, 60, 20), (25, 60, 110), (90, 30, 70)]
    img = Image.new("RGB", (W, H), colors[idx % len(colors)])
    d = ImageDraw.Draw(img)
    for y in range(0, H, 6):  # gradient nhẹ
        a = int(60 * y / H)
        d.line([(0, y), (W, y)], fill=tuple(max(0, c - a) for c in colors[idx % len(colors)]))
    img.save(path, quality=92)


def prepare_image(url, path, idx, prev):
    ok = False
    if url:
        try:
            r = requests.get(url, timeout=30, headers={"User-Agent": "Mozilla/5.0"})
            r.raise_for_status()
            raw = WORK / f"raw{idx}"
            raw.write_bytes(r.content)
            img = Image.open(raw).convert("RGB")
            ok = True
        except Exception as e:  # noqa
            log(f"tải ảnh {idx} lỗi: {e}")
    if not ok:
        if prev and Path(prev).exists():
            return prev
        fallback_image(path, idx)
        return path
    # cắt "cover" về tỉ lệ 9:16, phóng gấp đôi để zoom mượt không rung
    tw, th = W * 2, H * 2
    s = max(tw / img.width, th / img.height)
    img = img.resize((int(img.width * s) + 1, int(img.height * s) + 1), Image.LANCZOS)
    l, t = (img.width - tw) // 2, (img.height - th) // 2
    img.crop((l, t, l + tw, t + th)).save(path, quality=92)
    return path


# ---------------------------------------------------------------- 3. FFMPEG
MOTIONS = [
    # zoom vào giữa
    ("min(1+0.10*on/{n},1.10)", "iw/2-(iw/zoom/2)", "ih/2-(ih/zoom/2)"),
    # zoom ra
    ("max(1.12-0.12*on/{n},1.0)", "iw/2-(iw/zoom/2)", "ih/2-(ih/zoom/2)"),
    # lia trái -> phải
    ("1.10", "(iw-iw/zoom)*on/{n}", "ih/2-(ih/zoom/2)"),
    # lia trên -> dưới
    ("1.10", "iw/2-(iw/zoom/2)", "(ih-ih/zoom)*on/{n}"),
]


def scene_clip(img, dur, idx, out):
    n = max(1, int(round(dur * FPS)))
    z, x, y = (m.format(n=n) for m in MOTIONS[idx % len(MOTIONS)])
    vf = (f"zoompan=z='{z}':x='{x}':y='{y}':d={n}:s={W}x{H}:fps={FPS},"
          f"format=yuv420p")
    run(["ffmpeg", "-y", "-loglevel", "error", "-loop", "1", "-i", str(img),
         "-vf", vf, "-frames:v", str(n), "-c:v", "libx264", "-preset", "veryfast",
         "-crf", "20", str(out)])


def ass_time(t):
    t = max(0, t)
    h = int(t // 3600); m = int(t % 3600 // 60); s = t % 60
    return f"{h}:{m:02d}:{s:05.2f}"


def esc(t):
    return t.replace("\\", "").replace("{", "(").replace("}", ")")


def build_ass(all_words, total, title, path):
    # Màu ASS: &HAABBGGRR
    head = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Sub,{FONT_NAME},78,&H00FFFFFF,&H00FFFFFF,&H00000000,&H64000000,-1,0,0,0,100,100,0,0,1,6,3,2,60,60,560,1
Style: Brand,{FONT_NAME},40,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,-1,0,0,0,100,100,1,0,3,14,0,8,40,40,110,1
Style: Title,{FONT_NAME},64,&H0000D4FF,&H00FFFFFF,&H00000000,&H96000000,-1,0,0,0,100,100,0,0,3,22,0,8,70,70,260,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    ev = [f"Dialogue: 0,{ass_time(0)},{ass_time(total)},Brand,,0,0,0,,{esc(BRAND)}"]
    if title:
        ev.append(f"Dialogue: 0,{ass_time(0)},{ass_time(min(3.0, total))},Title,,0,0,0,,"
                  f"{{\\fad(200,300)}}{esc(title)}")
    # chia nhóm 4 chữ, chữ đang đọc tô vàng + phóng nhẹ
    groups = [all_words[i:i + WORDS_PER_LINE] for i in range(0, len(all_words), WORDS_PER_LINE)]
    for gi, g in enumerate(groups):
        g_end = groups[gi + 1][0][0] if gi + 1 < len(groups) else g[-1][1] + 0.4
        for wi, (s, e, _) in enumerate(g):
            end = g[wi + 1][0] if wi + 1 < len(g) else g_end
            if end - s < 0.05:
                continue
            parts = []
            for wj, (_, _, txt) in enumerate(g):
                txt = esc(txt)
                if wj == wi:
                    parts.append(f"{{\\c&H00D4FF&\\fscx112\\fscy112}}{txt}{{\\c&HFFFFFF&\\fscx100\\fscy100}}")
                else:
                    parts.append(txt)
            ev.append(f"Dialogue: 1,{ass_time(s)},{ass_time(end)},Sub,,0,0,0,,{' '.join(parts)}")
    Path(path).write_text(head + "\n".join(ev) + "\n", encoding="utf-8")


def load_payload():
    if len(sys.argv) > 1:
        return json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    raw = os.environ.get("PAYLOAD", "").strip()
    if not raw:
        sys.exit("Thiếu PAYLOAD")
    try:
        return json.loads(base64.b64decode(raw).decode("utf-8"))
    except Exception:
        return json.loads(raw)


def main():
    p = load_payload()
    scenes = [s for s in p.get("scenes", []) if (s.get("text") or "").strip()]
    if not scenes:
        sys.exit("Kịch bản không có cảnh nào")
    OUT.mkdir(exist_ok=True); WORK.mkdir(exist_ok=True)

    clips, audios, all_words = [], [], []
    t0, prev_img = 0.0, None
    for i, sc in enumerate(scenes):
        text = " ".join(sc["text"].split())
        mp3 = WORK / f"a{i}.mp3"
        words, adur = make_voice(text, mp3)
        dur = adur + SCENE_PAD
        # âm thanh cảnh: giọng + khoảng lặng cho đủ dur, chuẩn hoá về wav
        wav = WORK / f"a{i}.wav"
        run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(mp3), "-af",
             f"apad=whole_dur={dur}", "-ar", "44100", "-ac", "2", str(wav)])
        img = prepare_image(sc.get("image"), WORK / f"i{i}.jpg", i, prev_img)
        prev_img = img
        clip = WORK / f"v{i}.mp4"
        scene_clip(img, dur, i, clip)
        clips.append(clip); audios.append(wav)
        all_words += [[s + t0, e + t0, w] for s, e, w in words]
        t0 += dur
        log(f"cảnh {i + 1}/{len(scenes)}: {dur:.1f}s, {len(words)} chữ")

    (WORK / "v.txt").write_text("".join(f"file '{c.name}'\n" for c in clips))
    (WORK / "a.txt").write_text("".join(f"file '{a.name}'\n" for a in audios))
    run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0",
         "-i", str(WORK / "v.txt"), "-c", "copy", str(WORK / "video.mp4")])
    run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0",
         "-i", str(WORK / "a.txt"), "-c", "pcm_s16le", str(WORK / "voice.wav")])

    total = t0
    build_ass(all_words, total, p.get("title", ""), WORK / "sub.ass")

    inputs = ["-i", str(WORK / "video.mp4"), "-i", str(WORK / "voice.wav")]
    amix = "[1:a]anull[aout]"
    music = os.environ.get("MUSIC_FILE")
    if music and Path(music).exists():
        inputs += ["-stream_loop", "-1", "-i", music]
        amix = ("[2:a]volume=0.10,afade=t=out:st={:.2f}:d=1.5[m];"
                "[1:a][m]amix=inputs=2:duration=first:dropout_transition=0[aout]").format(max(0, total - 1.5))
    fontsdir = os.path.abspath(FONT_DIR)
    vf = f"[0:v]subtitles={WORK / 'sub.ass'}:fontsdir={fontsdir}[vout]"
    run(["ffmpeg", "-y", "-loglevel", "error", *inputs,
         "-filter_complex", f"{vf};{amix}", "-map", "[vout]", "-map", "[aout]",
         "-c:v", "libx264", "-preset", "medium", "-crf", "23", "-pix_fmt", "yuv420p",
         "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", "-t", f"{total:.2f}",
         str(OUT / "video.mp4")])

    size = (OUT / "video.mp4").stat().st_size
    meta = {k: p.get(k) for k in ("row", "title", "body", "hashtags", "p1")}
    meta.update(duration=round(total, 2), size_bytes=size)
    (OUT / "meta.json").write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")
    log(f"XONG: {total:.1f}s, {size / 1e6:.1f} MB")


if __name__ == "__main__":
    main()
